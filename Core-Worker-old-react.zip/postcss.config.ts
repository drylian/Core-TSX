/**
 * Codigo gerado com o tailwind padrão, doc usada
 * https://www.tailwindcss.cn/docs/guides/vite
 */
module.exports = {
	content: ["./resources/scripts/**/*.{js,ts,tsx}"],
	plugins: {
		tailwindcss: {},
		autoprefixer: {},
	},
};
