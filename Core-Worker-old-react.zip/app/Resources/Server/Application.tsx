export function Application() {
	return <div>teste</div>;
}
