"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// app/Resources/Server/Index.tsx
var Index_exports = {};
__export(Index_exports, {
  Renderize: () => Renderize
});
module.exports = __toCommonJS(Index_exports);
var import_server = __toESM(require("react-dom/server"));
var import_react = __toESM(require("react"));

// app/Resources/Server/Application.tsx
var import_jsx_runtime = require("react/jsx-runtime");
function Application() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "teste" });
}

// app/Resources/Server/Index.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
function Renderize(req, res) {
  const icon = req.core?.internal?.get("core:logo");
  const owner = req.core?.internal?.get("core:owner");
  return import_server.default.renderToString(
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_react.default.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("html", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("head", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("link", { rel: "icon", type: "image/png", href: icon }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("meta", { name: "viewport", content: "width=device-width, initial-scale=1.0" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("meta", { name: "author", content: owner })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("body", { className: "bg-white dark:bg-black transition duration-500", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { id: "application", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Application, {}) }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("script", { type: "module", src: "/reacter/resources.tsx" })
      ] })
    ] }) })
  );
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Renderize
});
